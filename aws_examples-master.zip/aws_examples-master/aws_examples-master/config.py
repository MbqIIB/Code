dbdetails = {
    "host": "localhost",
    "username": "username",
    "password": "password",
    "database": "dvdrental",
    "portno": "5432"
}
