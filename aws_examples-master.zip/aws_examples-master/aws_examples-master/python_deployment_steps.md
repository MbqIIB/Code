## Steps : 
pip install pipreqs

pipreqs projectpath

#### examples :  pipreqs C:\pyprojects\aws_s3_08292017

#### this process will create requirements.txt

pip install -r requirements.txt
